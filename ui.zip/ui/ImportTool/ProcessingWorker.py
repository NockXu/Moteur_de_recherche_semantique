from PyQt6.QtCore import QThread, pyqtSignal
from common.ImageInfo import ProcessingStatus, ImageInfo
from typing import List, Callable, Optional
import sys
import os

# Ajouter le chemin racine du projet au sys.path pour les imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from vision.ollama_wrapper import OllamaWrapper
from vision.ImageProcessor import ImageProcessor


class ProcessingWorker(QThread):
    """Worker thread pour traiter les images en arrière-plan"""
    
    # Signaux
    progress_updated = pyqtSignal(str, ProcessingStatus)  # image_path, status
    image_processed = pyqtSignal(str, str, list)  # image_path, description, embedding
    image_error = pyqtSignal(str, str)  # image_path, error_message
    processing_complete = pyqtSignal()
    
    def __init__(self, images: List[ImageInfo], ollama_wrapper: OllamaWrapper = None, model: str = "qwen2.5vl:7b"):
        super().__init__()
        self.images = images
        self.ollama_wrapper = ollama_wrapper
        self.model = model
        self._is_running = False
        self._current_index = 0
        
        # Initialiser l'ImageProcessor si le wrapper est disponible
        self.image_processor = None
        if self.ollama_wrapper:
            self.image_processor = ImageProcessor(self.ollama_wrapper, self.model)
    
    def run(self):
        """Traite toutes les images"""
        self._is_running = True
        self._current_index = 0
        
        try:
            for i, image_info in enumerate(self.images):
                # Vérifier fréquemment si on doit arrêter
                if not self._is_running:
                    print("⏹️ ProcessingWorker interrompu")
                    break
                
                self._current_index = i
                
                try:
                    self._process_single_image(image_info)
                except Exception as e:
                    print(f"❌ Erreur traitement image {image_info.path.name}: {e}")
                    # Continuer avec les autres images même si une échoue
                    continue
            
        except Exception as e:
            print(f"❌ Erreur globale dans ProcessingWorker: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            print("🏁 ProcessingWorker terminé")
            self.processing_complete.emit()
    
    def _process_single_image(self, image_info: ImageInfo):
        """Traite une seule image en utilisant ImageProcessor"""
        try:
            # Signaler le début du traitement
            image_info.status = ProcessingStatus.IN_PROGRESS
            self.progress_updated.emit(str(image_info.path), ProcessingStatus.IN_PROGRESS)
            
            if not self.image_processor:
                raise RuntimeError("ImageProcessor non initialisé - wrapper Ollama manquant")
            
            # Vérifier si on doit arrêter avant le traitement lourd
            if not self._is_running:
                print("⏹️ Arrêt demandé avant traitement de l'image")
                return
            
            # Créer un objet Image temporaire pour le traitement (ImageProcessor a besoin de la classe Image)
            from index.image import Image
            temp_image = Image(str(image_info.path))
            
            # Étape 1: Générer description et keywords avec ImageProcessor
            if not self._is_running:
                print("⏹️ Arrêt demandé avant génération description")
                return
            
            self.image_processor.ImageToData(temp_image)
            
            if not self._is_running:
                print("⏹️ Arrêt demandé après génération description")
                return
            
            if not temp_image.description:
                raise RuntimeError("Impossible de générer une description pour l'image")
            
            # Étape 2: Créer l'embedding à partir de la description
            if not self._is_running:
                print("⏹️ Arrêt demandé avant création embedding")
                return
            
            self.image_processor.TextToEmbedding(temp_image)
            
            if not self._is_running:
                print("⏹️ Arrêt demandé après création embedding")
                return
            
            if not temp_image.embedding:
                raise RuntimeError("Impossible de créer l'embedding")
            
            # Étape 3: Mettre à jour ImageInfo avec les résultats
            image_info.update_status(
                status=ProcessingStatus.COMPLETED,
                description=temp_image.description,
                keywords=temp_image.keywords,
                embedding=temp_image.embedding
            )
            
            # Étape 4: Sauvegarder les résultats avec ImageInfo
            if not self._is_running:
                print("⏹️ Arrêt demandé avant sauvegarde")
                return
            
            image_info.save_as_json(f"{image_info.path.stem}_{image_info.id}.json")
            
            # Signaler le succès
            self.progress_updated.emit(str(image_info.path), ProcessingStatus.COMPLETED)
            self.image_processed.emit(str(image_info.path), temp_image.description, temp_image.embedding)
            
        except Exception as e:
            # Signaler l'erreur
            error_msg = str(e)
            image_info.status = ProcessingStatus.ERROR
            image_info.error_message = error_msg
            self.progress_updated.emit(str(image_info.path), ProcessingStatus.ERROR)
            self.image_error.emit(str(image_info.path), error_msg)
    
    def stop(self):
        """Arrête le traitement proprement"""
        print("🛑 Arrêt du ProcessingWorker demandé...")
        self._is_running = False
        
        # Forcer l'arrêt si nécessaire
        if self.isRunning():
            self.quit()
    
    def is_running(self) -> bool:
        """Vérifie si le traitement est en cours"""
        return self._is_running
    
    def get_progress(self) -> float:
        """Retourne la progression actuelle (0.0 à 1.0)"""
        if not self.images:
            return 1.0
        
        return self._current_index / len(self.images)
    
    def get_current_image(self) -> Optional[str]:
        """Retourne le chemin de l'image actuellement traitée"""
        if 0 <= self._current_index < len(self.images):
            return str(self.images[self._current_index].path)
        return None


class BatchProcessingManager:
    """Gestionnaire pour traiter plusieurs lots d'images"""
    
    def __init__(self, ollama_wrapper: OllamaWrapper = None):
        self.ollama_wrapper = ollama_wrapper
        self.current_worker = None
        self.batch_size = 10  # Nombre d'images par lot
    
    def start_batch_processing(self, images: List[ImageInfo], 
                             on_progress: Callable = None,
                             on_image_processed: Callable = None,
                             on_image_error: Callable = None,
                             on_complete: Callable = None,
                             model: str = "qwen2.5vl:7b") -> ProcessingWorker:
        """Démarre le traitement par lot"""
        
        if self.current_worker and self.current_worker.is_running():
            raise RuntimeError("Un traitement est déjà en cours")
        
        # Diviser en lots si nécessaire
        if len(images) > self.batch_size:
            # Traiter le premier lot
            batch_images = images[:self.batch_size]
        else:
            batch_images = images
        
        # Créer et configurer le worker
        self.current_worker = ProcessingWorker(batch_images, self.ollama_wrapper, model)
        
        # Connecter les signaux
        if on_progress:
            self.current_worker.progress_updated.connect(on_progress)
        if on_image_processed:
            self.current_worker.image_processed.connect(on_image_processed)
        if on_image_error:
            self.current_worker.image_error.connect(on_image_error)
        if on_complete:
            self.current_worker.processing_complete.connect(on_complete)
        
        # Démarrer le worker
        self.current_worker.start()
        
        return self.current_worker
    
    def stop_current_processing(self):
        """Arrête le traitement en cours"""
        if self.current_worker and self.current_worker.is_running():
            self.current_worker.stop()
            self.current_worker.wait()  # Attendre que le thread se termine
    
    def is_processing(self) -> bool:
        """Vérifie si un traitement est en cours"""
        return (self.current_worker is not None and 
                self.current_worker.is_running())
    
    def get_current_progress(self) -> float:
        """Retourne la progression du traitement actuel"""
        if self.current_worker:
            return self.current_worker.get_progress()
        return 1.0
