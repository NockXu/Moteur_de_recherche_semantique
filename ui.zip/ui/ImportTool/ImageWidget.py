from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout
from PyQt6.QtCore import Qt, QSize, pyqtSignal
from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont, QPen
from pathlib import Path
from common.ImageInfo import ProcessingStatus


class ImageWidget(QWidget):
    """Widget pour afficher une image avec son badge de statut"""
    
    # Signal émis quand l'utilisateur clique sur l'image
    image_clicked = pyqtSignal(str)  # path de l'image
    
    def __init__(self, image_path: str, status: ProcessingStatus = ProcessingStatus.NOT_STARTED, 
                 status_icon: str = None, parent=None):
        super().__init__(parent)
        self.image_path = Path(image_path)
        self.status = status
        self.status_icon = status_icon
        self.thumbnail_size = QSize(150, 150)
        self.badge_size = QSize(30, 30)
        
        self.setFixedSize(self.thumbnail_size.width(), self.thumbnail_size.height() + 20)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.setStyleSheet("""
            ImageWidget {
                background-color: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                margin: 2px;
            }
            ImageWidget:hover {
                background-color: #e9ecef;
                border-color: #adb5bd;
            }
        """)
        
        self._setup_ui()
        self._load_thumbnail()
    
    def _setup_ui(self):
        """Configure l'interface du widget"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(2)
        
        # Widget pour l'image avec overlay
        self.image_container = QWidget()
        self.image_container.setFixedSize(self.thumbnail_size)
        self.image_container.setStyleSheet("background-color: transparent;")
        
        # Label pour l'image
        self.image_label = QLabel()
        self.image_label.setFixedSize(self.thumbnail_size)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("""
            QLabel {
                border-radius: 4px;
                background-color: #ffffff;
            }
        """)
        
        # Layout pour le container d'image
        container_layout = QVBoxLayout(self.image_container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.addWidget(self.image_label)
        
        layout.addWidget(self.image_container)
        
        # Label pour le nom du fichier
        self.name_label = QLabel(self.image_path.name[:15] + "..." if len(self.image_path.name) > 15 else self.image_path.name)
        self.name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.name_label.setStyleSheet("""
            QLabel {
                font-size: 10px;
                color: #495057;
                font-weight: 500;
            }
        """)
        self.name_label.setWordWrap(True)
        layout.addWidget(self.name_label)
    
    def _load_thumbnail(self):
        """Charge et affiche le thumbnail de l'image"""
        try:
            if self.image_path.exists():
                pixmap = QPixmap(str(self.image_path))
                if not pixmap.isNull():
                    # Redimensionner en gardant le ratio
                    scaled_pixmap = pixmap.scaled(
                        self.thumbnail_size, 
                        Qt.AspectRatioMode.KeepAspectRatio, 
                        Qt.TransformationMode.SmoothTransformation
                    )
                    self.image_label.setPixmap(scaled_pixmap)
                else:
                    self._show_error_image()
            else:
                self._show_error_image()
        except Exception:
            self._show_error_image()
    
    def _show_error_image(self):
        """Affiche une image d'erreur"""
        self.image_label.setText("⚠️")
        self.image_label.setStyleSheet("""
            QLabel {
                border-radius: 4px;
                background-color: #fff5f5;
                color: #dc3545;
                font-size: 24px;
                border: 1px solid #f8d7da;
            }
        """)
    
    def paintEvent(self, event):
        """Dessine le badge de statut par-dessus l'image"""
        super().paintEvent(event)
        
        if self.status == ProcessingStatus.NOT_STARTED:
            return  # Pas de badge pour non commencé
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Position du badge (coin supérieur droit)
        badge_x = self.thumbnail_size.width() - self.badge_size.width() - 5
        badge_y = 5
        
        # Couleur du badge selon le statut
        colors = {
            ProcessingStatus.IN_PROGRESS: QColor(255, 193, 7),  # Jaune
            ProcessingStatus.COMPLETED: QColor(40, 167, 69),   # Vert
            ProcessingStatus.ERROR: QColor(220, 53, 69)       # Rouge
        }
        
        badge_color = colors.get(self.status, QColor(108, 117, 125))  # Gris par défaut
        
        # Dessiner le cercle du badge
        painter.setBrush(badge_color)
        painter.setPen(QPen(badge_color.darker(120), 2))
        painter.drawEllipse(badge_x, badge_y, self.badge_size.width(), self.badge_size.height())
        
        # Dessiner l'icône si fournie
        if self.status_icon:
            painter.setPen(QPen(QColor(255, 255, 255), 2))  # Blanc pour l'icône
            font = QFont("Segoe UI", 12, QFont.Weight.Bold)
            painter.setFont(font)
            
            # Icônes selon le statut
            icons = {
                ProcessingStatus.IN_PROGRESS: "⏳",
                ProcessingStatus.COMPLETED: "✓",
                ProcessingStatus.ERROR: "✕"
            }
            
            icon_text = icons.get(self.status, "?")
            painter.drawText(
                badge_x, badge_y, self.badge_size.width(), self.badge_size.height(),
                Qt.AlignmentFlag.AlignCenter, icon_text
            )
    
    def mousePressEvent(self, event):
        """Gère le clic sur l'image"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.image_clicked.emit(str(self.image_path))
        super().mousePressEvent(event)
    
    def set_status(self, status: ProcessingStatus, status_icon: str = None):
        """Met à jour le statut de l'image"""
        self.status = status
        self.status_icon = status_icon
        self.update()  # Redessine le widget
    
    def get_status(self) -> ProcessingStatus:
        """Retourne le statut actuel"""
        return self.status
    
    def get_image_path(self) -> str:
        """Retourne le chemin de l'image"""
        return str(self.image_path)
