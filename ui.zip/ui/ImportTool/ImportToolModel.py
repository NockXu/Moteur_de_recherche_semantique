from pathlib import Path
from typing import List, Dict, Optional
from common.ImageInfo import ImageInfo, ProcessingStatus
from vision.ollama_wrapper import OllamaWrapper
from vision.ImageProcessor import ImageProcessor
import json


class ImportToolModel:
    """Modèle de données pour l'outil d'import d'images"""
    
    def __init__(self):
        self.images: List[ImageInfo] = []
        self.selected_folder: Optional[Path] = None
        self.supported_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'}
    
    def set_folder(self, folder_path: str) -> bool:
        """Définit le dossier sélectionné et charge les images"""
        try:
            folder = Path(folder_path)
            if not folder.exists() or not folder.is_dir():
                return False
            
            self.selected_folder = folder
            self._load_images_from_folder()
            return True
            
        except Exception:
            return False
    
    def _load_images_from_folder(self):
        """Charge toutes les images du dossier sélectionné"""
        self.images.clear()
        
        if not self.selected_folder:
            return
        
        # Parcourir récursivement le dossier
        for file_path in self.selected_folder.rglob('*'):
            if file_path.is_file() and file_path.suffix.lower() in self.supported_extensions:
                self.images.append(ImageInfo(str(file_path)))
    
    def get_images_count(self) -> int:
        """Retourne le nombre total d'images"""
        return len(self.images)
    
    def get_images_by_status(self) -> Dict[ProcessingStatus, int]:
        """Retourne le décompte des images par statut"""
        counts = {status: 0 for status in ProcessingStatus}
        
        for image_info in self.images:
            counts[image_info.status] += 1
        
        return counts
    
    def get_processed_count(self) -> int:
        """Retourne le nombre d'images traitées (terminées ou en erreur)"""
        return sum(1 for img in self.images if img.status in [ProcessingStatus.COMPLETED, ProcessingStatus.ERROR])
    
    def get_completed_count(self) -> int:
        """Retourne le nombre d'images terminées avec succès"""
        return sum(1 for img in self.images if img.status == ProcessingStatus.COMPLETED)
    
    def get_in_progress_count(self) -> int:
        """Retourne le nombre d'images en cours de traitement"""
        return sum(1 for img in self.images if img.status == ProcessingStatus.IN_PROGRESS)
    
    def get_error_count(self) -> int:
        """Retourne le nombre d'images avec erreur"""
        return sum(1 for img in self.images if img.status == ProcessingStatus.ERROR)
    
    def update_image_status(self, image_path: str, status: ProcessingStatus, 
                           description: str = "", keywords: List[str] = None, 
                           embedding: List[float] = None, error_message: str = ""):
        """Met à jour le statut d'une image spécifique"""
        image_path = Path(image_path).resolve()
        
        for image_info in self.images:
            if image_info.path.resolve() == image_path:
                image_info.update_status(
                    status=status,
                    description=description or None,
                    keywords=keywords,
                    embedding=embedding,
                    error_message=error_message or None
                )
                break
    
    def get_image_info(self, image_path: str) -> Optional[ImageInfo]:
        """Retourne les informations d'une image spécifique"""
        image_path = Path(image_path).resolve()
        
        for image_info in self.images:
            if image_info.path.resolve() == image_path:
                return image_info
        
        return None
    
    def get_all_images(self) -> List[ImageInfo]:
        """Retourne toutes les informations d'images"""
        return self.images.copy()
    
    def reset_all_status(self):
        """Réinitialise tous les statuts à NOT_STARTED"""
        for image_info in self.images:
            image_info.reset_processing()
    
    def save_results(self, output_file: str = None) -> bool:
        """Sauvegarde les résultats de traitement dans un fichier JSON"""
        try:
            if output_file is None:
                if not self.selected_folder:
                    return False
                output_file = self.selected_folder / "processing_results.json"
            
            # Créer le dossier de sortie si nécessaire
            output_path = Path(output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Préparer les données
            data = {
                "folder": str(self.selected_folder) if self.selected_folder else None,
                "total_images": len(self.images),
                "status_counts": {status.value: count for status, count in self.get_images_by_status().items()},
                "images": [img.to_dict() for img in self.images]
            }
            
            # Sauvegarder
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            return True
            
        except Exception:
            return False
    
    def load_results(self, input_file: str) -> bool:
        """Charge les résultats depuis un fichier JSON"""
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Recréer les informations d'images
            self.images = [ImageInfo.from_dict(img_data) for img_data in data["images"]]
            
            # Mettre à jour le dossier sélectionné si disponible
            if data.get("folder"):
                self.selected_folder = Path(data["folder"])
            
            return True
            
        except Exception:
            return False
    
    def is_processing_complete(self) -> bool:
        """Vérifie si toutes les images ont été traitées"""
        if not self.images:
            return True
        
        return all(img.status in [ProcessingStatus.COMPLETED, ProcessingStatus.ERROR] 
                  for img in self.images)
    
    def get_processing_progress(self) -> float:
        """Retourne la progression du traitement (0.0 à 1.0)"""
        if not self.images:
            return 1.0
        
        processed_count = self.get_processed_count()
        return processed_count / len(self.images)
