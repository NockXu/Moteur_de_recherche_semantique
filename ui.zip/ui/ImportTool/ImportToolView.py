import sys
import os

# Ajouter le chemin racine du projet au sys.path pour les imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QScrollArea, QFileDialog, QLabel, QFrame, 
                             QGridLayout, QProgressBar, QApplication)
from PyQt6.QtCore import Qt, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor
from pathlib import Path
from common.ImageInfo import ImageInfo, ProcessingStatus
from ui.ImportTool.ImportToolModel import ImportToolModel
from ui.ImportTool.ImageWidget import ImageWidget
from ui.ImportTool.widget.ConnectionVerificator import create_connection_verificator
from typing import List, Dict


class ImportToolView(QWidget):
    """Vue principale de l'outil d'import d'images"""
    
    # Signaux
    folder_selected = pyqtSignal(str)
    start_processing_requested = pyqtSignal()
    stop_processing_requested = pyqtSignal()
    image_clicked = pyqtSignal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.model = ImportToolModel()
        self.image_widgets: Dict[str, ImageWidget] = {}
        self.status_labels = {}
        
        # Créer le widget de vérification de connexion
        self.connection_verificator = create_connection_verificator()
        
        self._setup_ui()
        self._update_progress_display()
    
    def _setup_ui(self):
        """Configure l'interface utilisateur"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Header avec sélection de dossier
        self._setup_header(layout)
        
        # Zone d'affichage des images
        self._setup_image_area(layout)
        
        # Barre de progression
        self._setup_progress_bar(layout)
        
        # Footer avec actions
        self._setup_footer(layout)
    
    def _setup_header(self, parent_layout):
        """Configure la section d'en-tête"""
        header_frame = QFrame()
        header_frame.setFrameStyle(QFrame.Shape.StyledPanel)
        
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(15, 10, 15, 10)
        
        # Label du dossier
        self.folder_label = QLabel("Aucun dossier sélectionné")
        self.folder_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Medium))
        header_layout.addWidget(self.folder_label)
        
        header_layout.addStretch()
        
        # Widget de vérification de connexion Ollama
        header_layout.addWidget(self.connection_verificator.get_view())
        
        # Bouton de sélection de dossier
        self.select_folder_btn = QPushButton("📁 Sélectionner un dossier")
        self.select_folder_btn.setFont(QFont("Segoe UI", 11))
        self.select_folder_btn.setFixedHeight(40)
        self.select_folder_btn.clicked.connect(self._on_select_folder)
        header_layout.addWidget(self.select_folder_btn)
        
        parent_layout.addWidget(header_frame)
    
    def _setup_image_area(self, parent_layout):
        """Configure la zone d'affichage des images"""
        # Scroll area pour les images
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        
        # Widget container pour les images
        self.image_container = QWidget()
        self.image_layout = QGridLayout(self.image_container)
        self.image_layout.setSpacing(10)
        self.image_layout.setContentsMargins(15, 15, 15, 15)
        
        self.scroll_area.setWidget(self.image_container)
        parent_layout.addWidget(self.scroll_area, 1)  # Stretch factor 1
    
    def _setup_progress_bar(self, parent_layout):
        """Configure la barre de progression"""
        progress_frame = QFrame()
        progress_frame.setFrameStyle(QFrame.Shape.StyledPanel)
        
        progress_layout = QHBoxLayout(progress_frame)
        progress_layout.setContentsMargins(15, 10, 15, 10)
        
        # Récapitulatif des statuts
        self.status_summary = QWidget()
        self.status_layout = QHBoxLayout(self.status_summary)
        self.status_layout.setContentsMargins(0, 0, 0, 0)
        self.status_layout.setSpacing(20)
        
        self._create_status_labels()
        
        progress_layout.addWidget(self.status_summary)
        progress_layout.addStretch()
        
        # Compteur de progression
        self.progress_counter = QLabel("0 / 0")
        self.progress_counter.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        progress_layout.addWidget(self.progress_counter)
        
        # Barre de progression
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(20)
        progress_layout.addWidget(self.progress_bar)
        
        parent_layout.addWidget(progress_frame)
    
    def _setup_footer(self, parent_layout):
        """Configure la section de pied de page"""
        footer_layout = QHBoxLayout()
        
        # Bouton de démarrage/arrêt du traitement
        self.process_btn = QPushButton("▶️ Commencer le traitement")
        self.process_btn.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        self.process_btn.setFixedHeight(45)
        self.process_btn.setEnabled(False)
        self.process_btn.clicked.connect(self._on_process_clicked)
        footer_layout.addWidget(self.process_btn)
        
        footer_layout.addStretch()
        
        # Bouton de réinitialisation
        self.reset_btn = QPushButton("🔄 Réinitialiser")
        self.reset_btn.setFont(QFont("Segoe UI", 11))
        self.reset_btn.setFixedHeight(40)
        self.reset_btn.setEnabled(False)
        self.reset_btn.clicked.connect(self._on_reset_clicked)
        footer_layout.addWidget(self.reset_btn)
        
        parent_layout.addLayout(footer_layout)
    
    def _create_status_labels(self):
        """Crée les labels pour le récapitulatif des statuts"""
        status_config = {
            ProcessingStatus.NOT_STARTED: ("⏸️", "Non commencé"),
            ProcessingStatus.IN_PROGRESS: ("⏳", "En cours"),
            ProcessingStatus.COMPLETED: ("✅", "Terminé"),
            ProcessingStatus.ERROR: ("❌", "Erreur")
        }
        
        for status, (icon, text) in status_config.items():
            label = QLabel(f"{icon} {text}: 0")
            label.setFont(QFont("Segoe UI", 10))
            self.status_layout.addWidget(label)
            self.status_labels[status] = label
    
    def _on_select_folder(self):
        """Gère la sélection d'un dossier"""
        folder_path = QFileDialog.getExistingDirectory(
            self,
            "Sélectionner un dossier d'images",
            str(Path.home()),
            QFileDialog.Option.ShowDirsOnly
        )
        
        if folder_path:
            self.folder_selected.emit(folder_path)
    
    def _on_process_clicked(self):
        """Gère le clic sur le bouton de traitement"""
        if self.process_btn.text().startswith("▶️"):
            self.start_processing_requested.emit()
        else:
            self.stop_processing_requested.emit()
    
    def _on_reset_clicked(self):
        """Gère la réinitialisation"""
        self.model.reset_all_status()
        self._refresh_image_display()
        self._update_progress_display()
        self.process_btn.setText("▶️ Commencer le traitement")
        self.process_btn.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
            }
            QPushButton:hover {
                background-color: #218838;
            }
            QPushButton:pressed {
                background-color: #1e7e34;
            }
            QPushButton:disabled {
                background-color: #6c757d;
                cursor: not-allowed;
            }
        """)
    
    def set_folder(self, folder_path: str, success: bool):
        """Met à jour l'affichage après sélection d'un dossier"""
        if success:
            self.folder_label.setText(f"📁 {Path(folder_path).name}")
            self.select_folder_btn.setText("📁 Changer de dossier")
            self.process_btn.setEnabled(True)
            self.reset_btn.setEnabled(True)
        else:
            self.folder_label.setText("❌ Erreur lors de la sélection")
            self.process_btn.setEnabled(False)
            self.reset_btn.setEnabled(False)
    
    def load_images(self, images: List[ImageInfo]):
        """Charge et affiche les images"""
        self._clear_image_display()
        
        # Créer les widgets d'images
        cols = 5  # Nombre de colonnes
        for i, image_info in enumerate(images):
            widget = ImageWidget(str(image_info.path), image_info.status)
            widget.image_clicked.connect(self.image_clicked.emit)
            
            self.image_widgets[str(image_info.path)] = widget
            
            row = i // cols
            col = i % cols
            self.image_layout.addWidget(widget, row, col)
        
        self._update_progress_display()
    
    def _clear_image_display(self):
        """Efface tous les widgets d'images"""
        for i in reversed(range(self.image_layout.count())):
            child = self.image_layout.itemAt(i).widget()
            if child:
                child.setParent(None)
        self.image_widgets.clear()
    
    def _refresh_image_display(self):
        """Rafraîchit l'affichage des images"""
        images = self.model.get_all_images()
        self.load_images(images)
    
    def update_image_status(self, image_path: str, status: ProcessingStatus):
        """Met à jour le statut d'une image spécifique"""
        if image_path in self.image_widgets:
            widget = self.image_widgets[image_path]
            widget.set_status(status)
        
        self._update_progress_display()
    
    def _update_progress_display(self):
        """Met à jour l'affichage de la progression"""
        counts = self.model.get_images_by_status()
        total = self.model.get_images_count()
        processed = self.model.get_processed_count()
        
        # Mettre à jour les labels de statut
        status_config = {
            ProcessingStatus.NOT_STARTED: ("⏸️", "Non commencé"),
            ProcessingStatus.IN_PROGRESS: ("⏳", "En cours"),
            ProcessingStatus.COMPLETED: ("✅", "Terminé"),
            ProcessingStatus.ERROR: ("❌", "Erreur")
        }
        
        for status, (icon, text) in status_config.items():
            count = counts.get(status, 0)
            label = self.status_labels[status]
            label.setText(f"{icon} {text}: {count}")
        
        # Mettre à jour le compteur
        self.progress_counter.setText(f"{processed} / {total}")
        
        # Mettre à jour la barre de progression
        if total > 0:
            progress_percent = int((processed / total) * 100)
            self.progress_bar.setValue(progress_percent)
        else:
            self.progress_bar.setValue(0)
    
    def set_processing_mode(self, is_processing: bool):
        """Met à jour l'interface en mode traitement"""
        if is_processing:
            self.process_btn.setText("⏸️ Arrêter le traitement")
            self.select_folder_btn.setEnabled(False)
        else:
            self.process_btn.setText("▶️ Commencer le traitement")
            self.select_folder_btn.setEnabled(True)
    
    def get_model(self) -> ImportToolModel:
        """Retourne le modèle de données"""
        return self.model
    
    def get_connection_verificator(self):
        """Retourne le widget de vérification de connexion"""
        return self.connection_verificator
    
    def cleanup(self):
        """Nettoie les ressources"""
        if hasattr(self, 'connection_verificator'):
            self.connection_verificator.cleanup()


if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    
    window = ImportToolView()
    window.setWindowTitle("Import Tool - Test")
    window.setMinimumSize(800, 600)
    window.show()
    
    sys.exit(app.exec())
