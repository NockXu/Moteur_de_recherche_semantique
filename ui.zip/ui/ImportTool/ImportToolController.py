import sys
import os

# Ajouter le chemin racine du projet au sys.path pour les imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ui.ImportTool.ImportToolView import ImportToolView
from ui.ImportTool.ImportToolModel import ImportToolModel
from ui.ImportTool.ProcessingWorker import ProcessingWorker, BatchProcessingManager
from common.ImageInfo import ProcessingStatus, ImageInfo
from vision.ollama_wrapper import OllamaWrapper
from PyQt6.QtCore import QObject, pyqtSignal, QTime
from typing import Optional, Callable
from pathlib import Path


class ImportToolController(QObject):
    """Contrôleur pour l'outil d'import d'images"""
    
    # Signaux personnalisés
    processing_started = pyqtSignal()
    processing_finished = pyqtSignal()
    processing_stopped = pyqtSignal()
    image_processed = pyqtSignal(str, str, list)  # path, description, embedding
    image_error = pyqtSignal(str, str)  # path, error
    folder_loaded = pyqtSignal(int)  # nombre d'images chargées
    
    def __init__(self, ollama_wrapper: OllamaWrapper = None, model: str = "qwen2.5vl:7b", parent=None):
        super().__init__(parent)
        self.view = ImportToolView()
        self.model = self.view.get_model()
        self.ollama_wrapper = ollama_wrapper
        self.model_name = model  # Modèle de vision pour ImageProcessor
        self.processing_manager = BatchProcessingManager(ollama_wrapper)
        self.current_worker = None
        
        self._connect_signals()
    
    def _connect_signals(self):
        """Connecte les signaux de la vue aux méthodes du contrôleur"""
        # Signaux de la vue
        self.view.folder_selected.connect(self._handle_folder_selection)
        self.view.start_processing_requested.connect(self._start_processing)
        self.view.stop_processing_requested.connect(self._stop_processing)
        self.view.image_clicked.connect(self._handle_image_clicked)
    
    def _handle_folder_selection(self, folder_path: str):
        """Gère la sélection d'un dossier"""
        try:
            success = self.model.set_folder(folder_path)
            self.view.set_folder(folder_path, success)
            
            if success:
                images = self.model.get_all_images()
                self.view.load_images(images)
                self.folder_loaded.emit(len(images))
            else:
                self.folder_loaded.emit(0)
                
        except Exception as e:
            print(f"Erreur lors de la sélection du dossier: {e}")
            self.view.set_folder(folder_path, False)
            self.folder_loaded.emit(0)
    
    def _start_processing(self):
        """Démarre le traitement des images"""
        if self.processing_manager.is_processing():
            print("Un traitement est déjà en cours")
            return
        
        images = self.model.get_all_images()
        if not images:
            print("Aucune image à traiter")
            return
        
        # Réinitialiser les statuts si nécessaire
        has_unprocessed = any(img.status == ProcessingStatus.NOT_STARTED for img in images)
        if has_unprocessed:
            self.model.reset_all_status()
            self.view._refresh_image_display()
        
        try:
            # Démarrer le traitement
            self.current_worker = self.processing_manager.start_batch_processing(
                images,
                on_progress=self._on_image_progress,
                on_image_processed=self._on_image_processed,
                on_image_error=self._on_image_error,
                on_complete=self._on_processing_complete,
                model=self.model_name
            )
            
            self.view.set_processing_mode(True)
            self.processing_started.emit()
            
        except Exception as e:
            print(f"Erreur lors du démarrage du traitement: {e}")
            self.view.set_processing_mode(False)
    
    def _stop_processing(self):
        """Arrête le traitement en cours"""
        try:
            print("🛑 Demande d'arrêt du traitement...")
            
            # Arrêter le worker via le gestionnaire
            if hasattr(self, 'processing_manager') and self.processing_manager:
                self.processing_manager.stop_current_processing()
            
            # Arrêter directement le worker si nécessaire
            if hasattr(self, 'current_worker') and self.current_worker:
                if self.current_worker.isRunning():
                    print("⏹️ Arrêt du worker en cours...")
                    self.current_worker.stop()
            
            # Mettre à jour l'interface
            if hasattr(self, 'view'):
                self.view.set_processing_mode(False)
            
            # Émettre le signal
            self.processing_stopped.emit()
            
            print("✅ Traitement arrêté")
            
        except Exception as e:
            print(f"❌ Erreur lors de l'arrêt du traitement: {e}")
            import traceback
            traceback.print_exc()
            
            # Forcer la mise à jour de l'interface même en cas d'erreur
            try:
                if hasattr(self, 'view'):
                    self.view.set_processing_mode(False)
            except:
                pass
    
    def _on_image_progress(self, image_path: str, status: ProcessingStatus):
        """Gère la mise à jour de progression d'une image"""
        # Mettre à jour le modèle
        self.model.update_image_status(image_path, status)
        
        # Mettre à jour la vue
        self.view.update_image_status(image_path, status)
    
    def _on_image_processed(self, image_path: str, description: str, embedding: list):
        """Gère le traitement réussi d'une image"""
        # Mettre à jour le modèle avec les résultats
        self.model.update_image_status(
            image_path, 
            ProcessingStatus.COMPLETED,
            description=description,
            embedding=embedding
        )
        
        # Émettre le signal
        self.image_processed.emit(image_path, description, embedding)
        
        print(f"✅ Image traitée: {Path(image_path).name}")
    
    def _on_image_error(self, image_path: str, error_message: str):
        """Gère une erreur lors du traitement d'une image"""
        # Mettre à jour le modèle
        self.model.update_image_status(
            image_path,
            ProcessingStatus.ERROR,
            error_message=error_message
        )
        
        # Émettre le signal
        self.image_error.emit(image_path, error_message)
        
        print(f"❌ Erreur pour {Path(image_path).name}: {error_message}")
    
    def _on_processing_complete(self):
        """Gère la fin du traitement"""
        self.view.set_processing_mode(False)
        self.processing_finished.emit()
        
        # Afficher un résumé
        total = self.model.get_images_count()
        completed = self.model.get_completed_count()
        errors = self.model.get_error_count()
        
        print(f"\n📊 Traitement terminé:")
        print(f"   Total: {total} images")
        print(f"   ✅ Réussies: {completed}")
        print(f"   ❌ Erreurs: {errors}")
        print(f"   📈 Taux de succès: {(completed/total*100):.1f}%" if total > 0 else "   📈 Taux de succès: N/A")
    
    def _handle_image_clicked(self, image_path: str):
        """Gère le clic sur une image"""
        image_info = self.model.get_image_info(image_path)
        if image_info:
            print(f"\n📷 Image sélectionnée: {Path(image_path).name}")
            print(f"   📁 Chemin: {image_path}")
            print(f"   📊 Statut: {image_info.status.value}")
            
            if image_info.description:
                print(f"   📝 Description: {image_info.description}")
            
            if image_info.error_message:
                print(f"   ❌ Erreur: {image_info.error_message}")
            
            if image_info.embedding:
                print(f"   🧮 Embedding: {len(image_info.embedding)} dimensions")
    
    def get_view(self) -> ImportToolView:
        """Retourne la vue"""
        return self.view
    
    def get_model(self) -> ImportToolModel:
        """Retourne le modèle"""
        return self.model
    
    def set_ollama_wrapper(self, wrapper: OllamaWrapper):
        """Définit le wrapper Ollama pour le traitement"""
        self.ollama_wrapper = wrapper
        self.processing_manager.ollama_wrapper = wrapper
    
    def is_processing(self) -> bool:
        """Vérifie si un traitement est en cours"""
        return self.processing_manager.is_processing()
    
    def get_processing_progress(self) -> float:
        """Retourne la progression du traitement (0.0 à 1.0)"""
        return self.processing_manager.get_current_progress()
    
    def save_results(self, output_file: str = None) -> bool:
        """Sauvegarde les résultats de traitement"""
        return self.model.save_results(output_file)
    
    def load_results(self, input_file: str) -> bool:
        """Charge les résultats depuis un fichier"""
        success = self.model.load_results(input_file)
        if success:
            self.view._refresh_image_display()
            self.view._update_progress_display()
        return success
    
    def reset_all(self):
        """Réinitialise complètement l'outil"""
        # Arrêter le traitement en cours
        if self.is_processing():
            self._stop_processing()
        
        # Réinitialiser le modèle
        self.model.reset_all_status()
        
        # Réinitialiser la vue
        self.view._on_reset_clicked()
    
    def get_statistics(self) -> dict:
        """Retourne des statistiques sur les images"""
        counts = self.model.get_images_by_status()
        total = self.model.get_images_count()
        
        return {
            "total_images": total,
            "not_started": counts.get(ProcessingStatus.NOT_STARTED, 0),
            "in_progress": counts.get(ProcessingStatus.IN_PROGRESS, 0),
            "completed": counts.get(ProcessingStatus.COMPLETED, 0),
            "errors": counts.get(ProcessingStatus.ERROR, 0),
            "success_rate": (counts.get(ProcessingStatus.COMPLETED, 0) / total * 100) if total > 0 else 0,
            "selected_folder": str(self.model.selected_folder) if self.model.selected_folder else None
        }
    
    def get_status_info(self) -> dict:
        """Retourne les informations de statut actuelles"""
        return {
            "folder_selected": self.model.selected_folder is not None,
            "image_count": len(self.model.images),
            "processing": self.is_processing(),
            "selected_folder": str(self.model.selected_folder) if self.model.selected_folder else None
        }
    
    def get_connection_verificator(self):
        """Retourne le widget de vérification de connexion"""
        return self.view.get_connection_verificator()
    
    def cleanup(self):
        """Nettoie les ressources avant la fermeture"""
        try:
            print("🧹 Nettoyage des ressources...")
            
            # Arrêter le traitement en cours
            if self.is_processing():
                print("⏹️ Arrêt du traitement en cours...")
                self._stop_processing()
            
            # Attendre que le worker se termine proprement
            if hasattr(self, 'current_worker') and self.current_worker:
                if self.current_worker.isRunning():
                    print("⏳ Attente de la fin du worker...")
                    self.current_worker.quit()
                    
                    # Attendre plus longtemps pour permettre un arrêt propre
                    if not self.current_worker.wait(5000):  # 5 secondes
                        print("⚠️ Force l'arrêt du worker...")
                        self.current_worker.terminate()
                        self.current_worker.wait(2000)  # 2 secondes supplémentaires
                
                self.current_worker = None
            
            # Nettoyer le gestionnaire de traitement
            if hasattr(self, 'processing_manager'):
                self.processing_manager.current_worker = None
            
            # Nettoyer le ConnectionVerificator
            if hasattr(self, 'view') and self.view:
                try:
                    self.view.cleanup()
                except:
                    pass  # Ignorer les erreurs de nettoyage du ConnectionVerificator
            
            # Libérer la vue
            if hasattr(self, 'view') and self.view:
                try:
                    self.view.hide()
                    self.view.deleteLater()
                except:
                    pass  # Ignorer les erreurs de suppression de vue
            
            print("✅ Nettoyage terminé")
            
        except Exception as e:
            print(f"❌ Erreur lors du nettoyage: {e}")
            import traceback
            traceback.print_exc()
    
    def __del__(self):
        """Destructeur pour garantir le nettoyage"""
        self.cleanup()


# Fonction utilitaire pour créer une instance complète
def create_import_tool(ollama_wrapper: OllamaWrapper = None, model: str = "qwen2.5vl:7b") -> ImportToolController:
    """Crée une instance complète de l'outil d'import"""
    return ImportToolController(ollama_wrapper, model)


if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
    from PyQt6.QtCore import Qt
    from dotenv import load_dotenv
    
    # Charger les variables d'environnement
    load_dotenv()
    
    class TestWindow(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Test Import Tool")
            self.setMinimumSize(1000, 700)
            
            # Widget central
            central = QWidget()
            self.setCentralWidget(central)
            
            # Layout
            layout = QVBoxLayout(central)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(15)
            
            # Créer le wrapper Ollama si disponible
            wrapper = None
            ollama_url = os.getenv("OLLAMA_BASE_URL")
            if ollama_url:
                try:
                    wrapper = OllamaWrapper(ollama_url)
                    print(f"🔗 Connexion à Ollama: {ollama_url}")
                except Exception as e:
                    print(f"❌ Erreur de connexion à Ollama: {e}")
            else:
                print("⚠️ OLLAMA_BASE_URL non défini - traitement sans IA")
            
            # Créer le contrôleur
            self.import_controller = ImportToolController(wrapper, "qwen2.5vl:7b")
            
            # Connecter les signaux pour le test
            self.import_controller.folder_loaded.connect(self._on_folder_loaded)
            self.import_controller.processing_started.connect(self._on_processing_started)
            self.import_controller.processing_finished.connect(self._on_processing_finished)
            self.import_controller.image_processed.connect(self._on_image_processed)
            self.import_controller.image_error.connect(self._on_image_error)
            
            # Ajouter la vue
            layout.addWidget(self.import_controller.get_view())
        
        def _on_folder_loaded(self, count: int):
            print(f"📁 Dossier chargé: {count} image(s) trouvée(s)")
        
        def _on_processing_started(self):
            print("🚀 Début du traitement")
        
        def _on_processing_finished(self):
            stats = self.import_controller.get_statistics()
            print(f"✅ Traitement terminé - {stats['completed']}/{stats['total_images']} réussies")
        
        def _on_image_processed(self, path: str, description: str, embedding: list):
            print(f"✅ {Path(path).name}: {description[:30]}...")
        
        def _on_image_error(self, path: str, error: str):
            print(f"❌ {Path(path).name}: {error}")
        
        def closeEvent(self, event):
            """Ferme proprement les threads avant de quitter"""
            try:
                # Nettoyer le contrôleur
                self.import_controller.cleanup()
                
                # Forcer la fermeture de l'application
                QApplication.quit()
                
            except Exception as e:
                print(f"Erreur lors de la fermeture: {e}")
            finally:
                event.accept()
    
    # Lancer l'application
    app = QApplication(sys.argv)
    window = TestWindow()
    window.show()
    
    print("🚀 Test de l'Import Tool")
    print("💡 Sélectionnez un dossier d'images pour commencer")
    print("⚠️  Ctrl+C pour fermer proprement")
    
    # Gérer Ctrl+C pour une fermeture propre
    import signal
    def signal_handler(signum, frame):
        print("\n🛑 Interruption détectée, fermeture propre...")
        window.close()
        app.quit()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    # Exécuter l'application avec gestion d'erreurs
    try:
        exit_code = app.exec()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n🛑 Interruption clavier détectée")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Erreur inattendue: {e}")
        sys.exit(1)
