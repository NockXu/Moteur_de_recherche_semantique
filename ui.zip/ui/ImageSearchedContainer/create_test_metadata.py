import sys
import os
from pathlib import Path

# Ajouter le chemin racine du projet au sys.path pour les imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from index.image import Image


def create_test_metadata():
    """
    Crée des exemples de métadonnées au format spécifié
    """
    print("🚀 Création de métadonnées de test")
    print("=" * 50)
    
    # Exemples de données d'images
    test_images = [
        {
            "id": "img_0001",
            "path": "dataset/photo_01.jpg", 
            "description": "A rainy street at night with reflections on the ground.",
            "keywords": ["street", "night", "rain", "lights"],
            "embedding": [0.1, 0.2, 0.3, 0.4],  # Exemple d'embedding
            "indexed_at": "2026-04-17T10:30:00"
        },
        {
            "id": "img_0002", 
            "path": "dataset/photo_02.jpg",
            "description": "Sunset over mountains with orange and pink clouds.",
            "keywords": ["sunset", "mountains", "nature", "clouds"],
            "embedding": [0.5, 0.6, 0.7, 0.8],
            "indexed_at": "2026-04-17T10:31:00"
        },
        {
            "id": "img_0003",
            "path": "dataset/photo_03.jpg",
            "description": "Modern office building with glass facade.",
            "keywords": ["architecture", "office", "modern", "glass"],
            "embedding": [0.9, 1.0, 1.1, 1.2],
            "indexed_at": "2026-04-17T10:32:00"
        },
        {
            "id": "img_0004",
            "path": "dataset/photo_04.jpg", 
            "description": "Forest path in autumn with fallen leaves.",
            "keywords": ["forest", "autumn", "nature", "path"],
            "embedding": [1.3, 1.4, 1.5, 1.6],
            "indexed_at": "2026-04-17T10:33:00"
        },
        {
            "id": "img_0005",
            "path": "dataset/photo_05.jpg",
            "description": "Beach with waves and blue sky.",
            "keywords": ["beach", "ocean", "waves", "sky"],
            "embedding": [1.7, 1.8, 1.9, 2.0],
            "indexed_at": "2026-04-17T10:34:00"
        }
    ]
    
    # Créer les objets Image et les sauvegarder
    for i, data in enumerate(test_images, 1):
        try:
            # Créer l'objet Image à partir des métadonnées (sans vérifier le fichier)
            # On crée un objet Image temporaire qui ne vérifie pas le fichier
            from index.image import Image
            temp_image = Image.__new__(Image)  # Créer sans appeler __init__
            temp_image.id = data["id"]
            temp_image.path = data["path"]
            temp_image.description = data["description"]
            temp_image.keywords = data["keywords"]
            temp_image.embedding = data["embedding"]
            temp_image.name = Path(data["path"]).name
            
            # Sauvegarder en JSON
            filename = f"test_image_{i:02d}.json"
            temp_image.save_as_json(filename)
            
            print(f"✅ Créé: {filename}")
            print(f"   ID: {temp_image.id}")
            print(f"   Path: {temp_image.path}")
            print(f"   Description: {temp_image.description}")
            print(f"   Keywords: {temp_image.keywords}")
            print()
            
        except Exception as e:
            print(f"❌ Erreur lors de la création de l'image {i}: {str(e)}")
    
    print("🎯 Métadonnées de test créées avec succès !")
    print("💡 Vous pouvez maintenant utiliser autoResearchDataset.py pour les charger")
    print("📁 Les fichiers ont été sauvegardés dans le dossier storage")


def test_image_creation():
    """
    Test la création d'objets Image directement
    """
    print("\n🧪 Test de création d'objets Image:")
    print("-" * 30)
    
    # Créer quelques images directement (sans vérifier les fichiers)
    direct_images = []
    
    for i, data in enumerate([
        {"path": "dataset/direct_01.jpg", "description": "Direct creation test 1", "keywords": ["test", "direct"], "embedding": [0.1, 0.2, 0.3, 0.4], "id": "direct_001"},
        {"path": "dataset/direct_02.jpg", "description": "Direct creation test 2", "keywords": ["test", "direct"], "embedding": [0.5, 0.6, 0.7, 0.8], "id": "custom_id_001"}
    ], 1):
        try:
            # Créer l'objet Image sans vérifier le fichier
            from index.image import Image
            temp_image = Image.__new__(Image)
            temp_image.id = data["id"]
            temp_image.path = data["path"]
            temp_image.description = data["description"]
            temp_image.keywords = data["keywords"]
            temp_image.embedding = data["embedding"]
            temp_image.name = Path(data["path"]).name
            
            # Sauvegarder
            filename = f"direct_image_{i}.json"
            temp_image.save_as_json(filename)
            
            print(f"✅ Image directe {i}:")
            print(f"   ID: {temp_image.id}")
            print(f"   Fichier: {filename}")
            print(f"   Path: {temp_image.path}")
            print()
            
        except Exception as e:
            print(f"❌ Erreur lors de la création de l'image {i}: {str(e)}")


if __name__ == "__main__":
    # Créer les métadonnées de test
    create_test_metadata()
    
    # Tester la création directe
    test_image_creation()
    
    print("\n🎯 Terminé !")
    print("💡 Les métadonnées sont prêtes à être utilisées avec:")
    print("   - autoResearchDataset.py (pour charger)")
    print("   - ImageSearchedContainer (pour afficher)")
