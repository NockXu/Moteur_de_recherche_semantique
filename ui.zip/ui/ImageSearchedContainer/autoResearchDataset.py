import sys
import os
import json
from pathlib import Path
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# Ajouter le chemin racine du projet au sys.path pour les imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from index.image import Image
from ui.ImageSearchedContainer.ImageSearchedContainerModel import ImageInfo


class ImageDatasetLoader:
    """
    Classe pour parcourir efficacement le dossier storage et charger toutes les images
    avec leurs métadonnées sauvegardées
    """
    
    def __init__(self, storage_path: str = None):
        if storage_path is None:
            # Chemin par défaut vers le dossier storage (chercher dans plusieurs endroits possibles)
            possible_paths = [
                Path(__file__).parent.parent / "storage",  # ui/storage
                Path(__file__).parent.parent.parent / "storage",  # projet/storage
                Path("storage")  # storage local
            ]
            
            # Utiliser le premier chemin qui existe
            for path in possible_paths:
                if path.exists():
                    self.storage_path = path
                    break
            else:
                self.storage_path = possible_paths[0]  # Défaut au premier
        else:
            self.storage_path = Path(storage_path)
            
        # Créer le dossier storage s'il n'existe pas
        self.storage_path.mkdir(exist_ok=True)
        
        # Extensions d'images supportées
        self.image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'}
        
    def find_all_images(self, recursive: bool = True, max_workers: int = 4) -> List[Image]:
        """
        Trouve toutes les images dans le dossier storage et les charge avec leurs métadonnées
        
        Args:
            recursive: Si True, parcourt tous les sous-dossiers
            max_workers: Nombre de workers pour le chargement parallèle
            
        Returns:
            Liste d'objets Image avec leurs métadonnées
        """
        print(f"🔍 Recherche d'images dans: {self.storage_path}")
        start_time = time.time()
        
        # 1. Trouver tous les fichiers image
        image_files = self._find_image_files(recursive)
        print(f"📁 {len(image_files)} fichiers image trouvés")
        
        if not image_files:
            print("❌ Aucune image trouvée")
            return []
        
        # 2. Charger les métadonnées en parallèle
        images = self._load_images_with_metadata(image_files, max_workers)
        
        elapsed_time = time.time() - start_time
        print(f"✅ {len(images)} images chargées en {elapsed_time:.2f}s")
        
        return images
    
    def _find_image_files(self, recursive: bool) -> List[Path]:
        """
        Trouve tous les fichiers image dans le dossier storage.
        Cherche d'abord les métadonnées JSON, puis les fichiers image.
        """
        image_files = []
        
        if recursive:
            # 1. D'abord, chercher tous les fichiers JSON de métadonnées
            json_files = list(self.storage_path.rglob('*.json'))
            print(f"📄 {len(json_files)} fichiers JSON trouvés")
            
            # 2. Ensuite, chercher les fichiers image correspondants
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        metadata = json.load(f)
                        image_path = Path(metadata.get('path', ''))
                        
                        # Vérifier que le fichier image existe
                        if image_path.exists() and image_path.is_file():
                            image_files.append(image_path)
                            print(f"✓ {image_path.name} (depuis {json_file.name})")
                        else:
                            print(f"⚠️ {image_path.name} (fichier manquant)")
                except Exception as e:
                    print(f"⚠️ Erreur lecture {json_file.name}: {str(e)}")
            
            # 3. Ajouter les fichiers image sans métadonnées
            for file_path in self.storage_path.rglob('*'):
                if (file_path.is_file() and 
                    file_path.suffix.lower() in self.image_extensions and
                    file_path not in image_files):  # Éviter les doublons
                    image_files.append(file_path)
                    print(f"+ {file_path.name} (sans métadonnées)")
        else:
            # Parcours simple du dossier racine
            json_files = list(self.storage_path.glob('*.json'))
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        metadata = json.load(f)
                        image_path = Path(metadata.get('path', ''))
                        if image_path.exists() and image_path.is_file():
                            image_files.append(image_path)
                except Exception:
                    pass
                    
            for file_path in self.storage_path.iterdir():
                if (file_path.is_file() and 
                    file_path.suffix.lower() in self.image_extensions and
                    file_path not in image_files):
                    image_files.append(file_path)
        
        return sorted(list(set(image_files)))  # Éliminer les doublons
    
    def _load_images_with_metadata(self, image_files: List[Path], max_workers: int) -> List[Image]:
        """Charge les images et leurs métadonnées en parallèle"""
        images = []
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Soumettre toutes les tâches de chargement
            future_to_path = {
                executor.submit(self._load_single_image, file_path): file_path 
                for file_path in image_files
            }
            
            # Récupérer les résultats au fur et à mesure
            for future in as_completed(future_to_path):
                file_path = future_to_path[future]
                try:
                    image = future.result()
                    if image:
                        images.append(image)
                        print(f"✓ {file_path.name}")
                except Exception as e:
                    print(f"✗ Erreur lors du chargement de {file_path.name}: {str(e)}")
        
        return images
    
    def _load_single_image(self, file_path: Path) -> Optional[Image]:
        """
        Charge une image individuelle avec ses métadonnées
        
        Args:
            file_path: Chemin vers le fichier image
            
        Returns:
            Objet Image ou None si erreur
        """
        try:
            # Chercher le fichier de métadonnées correspondant
            metadata_file = self._find_metadata_file(file_path)
            
            if metadata_file and metadata_file.exists():
                # Charger les métadonnées depuis le fichier JSON
                return self._load_image_from_metadata(metadata_file)
            else:
                # Créer une image avec métadonnées par défaut
                return Image(
                    path=str(file_path),
                    description=f"Image {file_path.name}",
                    keywords=[],
                    embedding=[]
                )
                
        except Exception as e:
            print(f"Erreur lors du chargement de {file_path}: {str(e)}")
            return None
    
    def _find_metadata_file(self, image_path: Path) -> Optional[Path]:
        """
        Trouve le fichier de métadonnées correspondant à une image
        
        Cherche les fichiers avec le même nom mais extension .json
        Priorité: même dossier > dossier storage > recherche par nom d'image
        """
        # 1. Chercher dans le même dossier que l'image
        metadata_path = image_path.with_suffix('.json')
        if metadata_path.exists():
            return metadata_path
            
        # 2. Chercher dans le dossier storage principal avec le même nom
        metadata_path = self.storage_path / f"{image_path.stem}.json"
        if metadata_path.exists():
            return metadata_path
            
        # 3. Chercher dans tout le dossier storage un fichier JSON qui contient ce chemin d'image
        try:
            for json_file in self.storage_path.glob('*.json'):
                with open(json_file, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                    if metadata.get('path') == str(image_path):
                        return json_file
        except Exception:
            pass
            
        return None
    
    def _load_image_from_metadata(self, metadata_file: Path) -> Optional[Image]:
        """
        Charge une image à partir de son fichier de métadonnées
        Format attendu: {"id", "path", "description", "keywords", "embedding", "indexed_at"}
        """
        try:
            with open(metadata_file, 'r', encoding='utf-8') as f:
                metadata = json.load(f)
                
                # Vérifier que le format est correct
                if not all(key in metadata for key in ['path', 'description', 'keywords']):
                    print(f"⚠️ Format de métadonnées invalide dans {metadata_file}")
                    return None
                
                # Créer l'objet Image avec les données du JSON
                return Image(
                    path=metadata['path'],
                    description=metadata.get('description', ''),
                    keywords=metadata.get('keywords', []),
                    embedding=metadata.get('embedding', [])
                )
        except Exception as e:
            print(f"Erreur lors de la lecture des métadonnées {metadata_file}: {str(e)}")
            return None
    
    def get_storage_stats(self) -> Dict:
        """Retourne des statistiques sur le dossier storage"""
        stats = {
            'storage_path': str(self.storage_path),
            'total_files': 0,
            'image_files': 0,
            'metadata_files': 0,
            'file_types': {},
            'total_size_mb': 0
        }
        
        try:
            for file_path in self.storage_path.rglob('*'):
                if file_path.is_file():
                    stats['total_files'] += 1
                    file_size = file_path.stat().st_size
                    stats['total_size_mb'] += file_size / (1024 * 1024)
                    
                    suffix = file_path.suffix.lower()
                    if suffix in self.image_extensions:
                        stats['image_files'] += 1
                        stats['file_types'][suffix] = stats['file_types'].get(suffix, 0) + 1
                    elif suffix == '.json':
                        stats['metadata_files'] += 1
            
            stats['total_size_mb'] = round(stats['total_size_mb'], 2)
            
        except Exception as e:
            print(f"Erreur lors du calcul des statistiques: {str(e)}")
        
        return stats
    
    def create_image_infos(self, images: List[Image], default_score: float = 0.0) -> List[ImageInfo]:
        """
        Convertit une liste d'objets Image en ImageInfo pour le conteneur
        
        Args:
            images: Liste d'objets Image
            default_score: Score par défaut pour les images
            
        Returns:
            Liste d'objets ImageInfo
        """
        return [
            ImageInfo(image=image, score=default_score)
            for image in images
        ]


def main():
    """Fonction principale pour tester le chargeur de dataset"""
    print("🚀 Chargeur de dataset d'images")
    print("=" * 50)
    
    # Créer le chargeur
    loader = ImageDatasetLoader()
    
    # Afficher les statistiques du storage
    print("\n📊 Statistiques du dossier storage:")
    stats = loader.get_storage_stats()
    for key, value in stats.items():
        if key == 'file_types':
            print(f"  {key}: {value}")
        else:
            print(f"  {key}: {value}")
    
    print("\n🔍 Chargement des images...")
    images = loader.find_all_images(recursive=True, max_workers=4)
    
    if images:
        print(f"\n✅ Succès: {len(images)} images chargées")
        
        # Créer les ImageInfo pour le conteneur
        image_infos = loader.create_image_infos(images, default_score=1.0)
        
        # Afficher quelques exemples
        print("\n📋 Exemples d'images chargées:")
        for i, img_info in enumerate(image_infos[:5]):
            print(f"  {i+1}. {img_info.image.name}")
            print(f"     Path: {img_info.image.path}")
            print(f"     Keywords: {img_info.image.keywords}")
            print(f"     Score: {img_info.score}")
        
        if len(image_infos) > 5:
            print(f"  ... et {len(image_infos) - 5} autres")
            
        return image_infos
    else:
        print("\n❌ Aucune image trouvée")
        return []


if __name__ == "__main__":
    image_infos = main()
    
    if image_infos:
        print(f"\n🎯 {len(image_infos)} ImageInfo prêtes à être utilisées")
        print("💡 Vous pouvez maintenant les utiliser avec ImageSearchedContainerController:")
        print("   controller.set_images([img_info.image for img_info in image_infos], [img_info.score for img_info in image_infos])")
