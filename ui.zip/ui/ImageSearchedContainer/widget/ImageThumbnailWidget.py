from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QFont


class ImageThumbnailWidget(QWidget):
    """Miniature d'image avec titre, hauteur dynamique (style Pinterest)."""

    clicked = pyqtSignal(str)

    def __init__(self, image_path: str, title: str = "", col_width: int = 200):
        super().__init__()
        self.image_path = image_path
        self.title = title
        self.col_width = col_width
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Image
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self._load_image()

        # Titre
        self.title_label = QLabel(self.title)
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.title_label.setWordWrap(True)
        self.title_label.setFont(QFont("Segoe UI", 9))
        self.title_label.setContentsMargins(8, 6, 8, 8)

        layout.addWidget(self.image_label)
        layout.addWidget(self.title_label)

        self.image_label.mousePressEvent = lambda e: self.clicked.emit(self.image_path)

    def _load_image(self):
        """Charge l'image et adapte la hauteur au ratio réel."""
        pixmap = QPixmap(self.image_path)
        if not pixmap.isNull():
            scaled = pixmap.scaledToWidth(
                self.col_width,
                Qt.TransformationMode.SmoothTransformation
            )
            self.image_label.setPixmap(scaled)
            self.image_label.setFixedSize(scaled.width(), scaled.height())
        else:
            self.image_label.setText("Image introuvable")
            self.image_label.setFixedSize(self.col_width, self.col_width)

    def _apply_styles(self):
        self.setStyleSheet("""
            ImageThumbnailWidget {
                background-color: #ffffff;
                border-radius: 10px;
            }
            ImageThumbnailWidget:hover {
                background-color: #f1f3f9;
            }
            QLabel {
                color: #495057;
            }
        """)