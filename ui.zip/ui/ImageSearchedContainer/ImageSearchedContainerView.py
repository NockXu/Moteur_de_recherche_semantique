import sys
import os

# Ajouter le chemin racine du projet au sys.path pour les imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QScrollArea
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from ui.ImageSearchedContainer.widget.ImageThumbnailWidget import ImageThumbnailWidget
from ui.ImageSearchedContainer.widget.PaginationWidget import PaginationWidget
from ui.ImageSearchedContainer.widget.MasonryWidget import MasonryLayout


class ImageSearchedContainerView(QWidget):
    """
    Vue principale : header + grille masonry scrollable + pagination.
    Ne gère pas la logique de pagination — c'est le Controller qui
    appelle display_images() avec la tranche déjà calculée.
    """

    image_clicked = pyqtSignal(str)
    page_changed  = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header
        self.header_label = QLabel("0 image trouvée")
        self.header_label.setFont(QFont("Segoe UI", 10))
        self.header_label.setContentsMargins(16, 12, 16, 12)
        layout.addWidget(self.header_label)

        # Zone scrollable
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        # Layout masonry
        self.masonry = MasonryLayout()
        self.masonry.image_clicked.connect(self.image_clicked)
        self.scroll_area.setWidget(self.masonry)
        layout.addWidget(self.scroll_area, stretch=1)

        # Pagination
        self.pagination = PaginationWidget()
        self.pagination.page_changed.connect(self.page_changed)
        layout.addWidget(self.pagination)

    def _apply_styles(self):
        self.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #f0f2f5;
            }
            MasonryLayout {
                background-color: #f0f2f5;
            }
            QLabel#header {
                color: #6c757d;
                font-size: 10pt;
            }
        """)
        self.header_label.setObjectName("header")

    # ------------------------------------------------------------------
    # API appelée par le Controller
    # ------------------------------------------------------------------

    def display_images(self, image_data: list[dict], total_count: int,
                       current_page: int, total_pages: int):
        """
        Affiche une tranche d'images (déjà filtrée/triée/paginée par le modèle).

        image_data : liste de dicts {'path', 'title', ...}
        total_count : nombre total d'images (pour le header)
        """
        # Header
        n = total_count
        self.header_label.setText(f"{n} image{'s' if n > 1 else ''} trouvée{'s' if n > 1 else ''}")

        # Pagination
        self.pagination.set_total_pages(total_pages)
        self.pagination.set_page(current_page)

        # Cartes
        cards = []
        for data in image_data:
            card = ImageThumbnailWidget(
                image_path=data.get("path", ""),
                title=data.get("title", ""),
            )
            card.clicked.connect(self.image_clicked)
            cards.append(card)

        self.masonry.set_cards(cards)

    def clear(self):
        self.header_label.setText("0 image trouvée")
        self.masonry.clear()
        self.pagination.set_total_pages(1)
        self.pagination.set_page(1)