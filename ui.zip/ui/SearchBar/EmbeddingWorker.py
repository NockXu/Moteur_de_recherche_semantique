from PyQt6.QtCore import QObject, QThread, pyqtSignal


class EmbeddingWorker(QObject):
    """Worker pour effectuer l'embedding dans un thread séparé"""
    finished = pyqtSignal(list)  # Signal émis quand l'embedding est terminé
    error = pyqtSignal(str)     # Signal émis en cas d'erreur
    
    def __init__(self, model, text, wrapper=None):
        super().__init__()
        self.model = model
        self.text = text
        self.wrapper = wrapper
    
    def run(self):
        """Effectue l'embedding de manière synchrone dans ce thread"""
        try:
            embedding = self.model.embed_input(wrapper=self.wrapper, text=self.text)
            self.finished.emit(embedding)
        except ValueError as e:
            self.error.emit(f"Erreur de validation: {str(e)}")
        except ConnectionError as e:
            self.error.emit(f"Erreur de connexion Ollama: {str(e)}")
        except TimeoutError as e:
            self.error.emit(f"Timeout Ollama: {str(e)}")
        except RuntimeError as e:
            self.error.emit(f"Erreur d'embedding: {str(e)}")
        except Exception as e:
            self.error.emit(f"Erreur inattendue: {str(e)}")


class AsyncEmbeddingManager:
    """Gestionnaire pour lancer des embeddings asynchrones"""
    
    def __init__(self):
        self.current_worker = None
        self.current_thread = None
    
    def start_embedding(self, model, text, wrapper=None, on_finished=None, on_error=None):
        """Démarre un embedding asynchrone"""
        # Nettoyer le thread précédent s'il existe
        if self.current_thread:
            if self.current_thread.isRunning():
                self.current_thread.quit()
                self.current_thread.wait()
            self.current_thread = None
            self.current_worker = None
        
        # Créer le worker et le thread
        self.current_worker = EmbeddingWorker(model, text, wrapper)
        self.current_thread = QThread()
        
        # Déplacer le worker vers le thread
        self.current_worker.moveToThread(self.current_thread)
        
        # Connecter les signaux
        self.current_thread.started.connect(self.current_worker.run)
        
        # Nettoyer automatiquement quand terminé
        self.current_worker.finished.connect(self._cleanup_thread)
        
        # Connecter les callbacks personnalisés
        if on_finished:
            self.current_worker.finished.connect(on_finished)
        if on_error:
            self.current_worker.error.connect(on_error)
        
        # Démarrer le thread
        self.current_thread.start()
        
        return self.current_worker, self.current_thread
    
    def _cleanup_thread(self):
        """Nettoie le thread et le worker après exécution"""
        if self.current_thread:
            if self.current_thread.isRunning():
                self.current_thread.quit()
                self.current_thread.wait(1000)  # Attendre max 1 seconde
            self.current_thread.deleteLater()
            self.current_thread = None
        if self.current_worker:
            self.current_worker.deleteLater()
            self.current_worker = None
    
    def is_running(self):
        """Vérifie si un embedding est en cours"""
        return self.current_thread and self.current_thread.isRunning()
    
    def stop_embedding(self):
        """Arrête l'embedding en cours"""
        if self.current_thread and self.current_thread.isRunning():
            self.current_thread.quit()
            self.current_thread.wait()
