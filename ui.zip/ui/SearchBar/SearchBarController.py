
import sys
import os

# Ajouter le chemin racine du projet au sys.path pour les imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from ui.SearchBar.SearchBarView import SearchBarView
from ui.SearchBar.SearchBarModel import SearchBarModel
from ui.SearchBar.EmbeddingWorker import AsyncEmbeddingManager
from vision.ollama_wrapper import OllamaWrapper


class SearchBarController:
    def __init__(self, ollama_wrapper: OllamaWrapper = None):
        self.view = SearchBarView()
        self.model = SearchBarModel()
        self.ollama_wrapper = ollama_wrapper
        self.embedding_manager = AsyncEmbeddingManager()
        self._connect_signals()
        
    def _connect_signals(self):
        self.view.search_triggered.connect(self._handle_search)
        self.view.search_text_changed.connect(self._handle_text_changed)
        
    def _handle_search(self):
        """Lance l'embedding de manière asynchrone pour ne pas bloquer l'UI"""
        if not self.model.text or not self.model.text.strip():
            return
            
        # Vérifier que le wrapper Ollama est disponible
        if self.ollama_wrapper is None:
            self._on_embedding_error("Wrapper Ollama non configuré - impossible d'effectuer la recherche")
            return
            
        # Désactiver la barre de recherche pendant l'embedding
        self.view.set_enabled(False)
        
        # Appeler la méthode de statut si disponible (pour le test)
        if hasattr(self, '_update_search_status'):
            self._update_search_status(self.model.text)
        
        # Lancer l'embedding asynchrone avec le wrapper
        self.embedding_manager.start_embedding(
            model=self.model,
            text=self.model.text,
            wrapper=self.ollama_wrapper,
            on_finished=self._on_embedding_finished,
            on_error=self._on_embedding_error
        )
    
    def _on_embedding_finished(self, embedding):
        """Appelé quand l'embedding est terminé"""
        # Réactiver la barre de recherche
        self.view.set_enabled(True)
        
        # Ici vous pouvez ajouter la logique de recherche avec les embeddings
        print(f"Embedding terminé: {len(embedding)} dimensions")
        
        # Vous pouvez émettre un signal ou appeler une callback ici
        # pour notifier l'application que les résultats sont prêts
    
    def _on_embedding_error(self, error_msg):
        """Appelé en cas d'erreur pendant l'embedding"""
        # Réactiver la barre de recherche
        self.view.set_enabled(True)
        print(f"Erreur d'embedding: {error_msg}")
        
    def _handle_text_changed(self, text):
        self.model.text = text
        
    def get_current_text(self):
        return self.model.text
        
    def set_text(self, text):
        self.model.text = text
        
    def clear_search(self):
        self.view.clear()
        self.model.clear()

if __name__ == "__main__":
    import sys
    import os
    from dotenv import load_dotenv
    from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, QTextEdit
    from PyQt6.QtCore import Qt

    # Charger les variables d'environnement depuis le fichier .env
    load_dotenv()
    
    # Créer le wrapper Ollama
    ollama_url = os.getenv("OLLAMA_BASE_URL")
    if not ollama_url:
        print("Erreur: OLLAMA_BASE_URL non défini dans le fichier .env")
        sys.exit(1)
    
    wrapper = OllamaWrapper(ollama_url)
    print(f"Connexion à Ollama: {ollama_url}")

    class TestWindow(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Test Barre de Recherche avec Ollama")
            self.setMinimumSize(800, 600)
            
            # Widget central
            central = QWidget()
            self.setCentralWidget(central)
            
            # Layout
            layout = QVBoxLayout(central)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(15)
            
            # Label d'instructions
            instructions = QLabel("Test de la barre de recherche avec embedding Ollama:")
            instructions.setStyleSheet("font-weight: bold; font-size: 14px; color: #333;")
            layout.addWidget(instructions)
            
            # Créer le contrôleur avec le wrapper
            self.search_controller = SearchBarController(ollama_wrapper=wrapper)
            
            # Remplacer les callbacks du contrôleur pour afficher les résultats
            self.original_on_finished = self.search_controller._on_embedding_finished
            self.original_on_error = self.search_controller._on_embedding_error
            self.search_controller._on_embedding_finished = self._on_embedding_finished
            self.search_controller._on_embedding_error = self._on_embedding_error
            
            layout.addWidget(self.search_controller.view)
            
            # Zone de résultats
            self.results_area = QTextEdit()
            self.results_area.setPlaceholderText("Les résultats d'embedding apparaîtront ici...")
            self.results_area.setMaximumHeight(200)
            self.results_area.setStyleSheet("""
                QTextEdit {
                    background-color: #f5f5f5;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    padding: 10px;
                    font-family: 'Courier New', monospace;
                }
            """)
            layout.addWidget(self.results_area)
            
            # Label de statut
            self.status_label = QLabel("Prêt à tester...")
            self.status_label.setStyleSheet("color: #666; font-style: italic;")
            layout.addWidget(self.status_label)
            
        def _update_search_status(self, text):
            """Met à jour le statut de recherche"""
            self.status_label.setText(f"Recherche en cours pour: '{text}'...")
            self.results_area.clear()
        
        def _on_embedding_finished(self, embedding):
            """Affiche les résultats de l'embedding"""
            self.search_controller.view.set_enabled(True)
            self.status_label.setText("Embedding terminé avec succès!")
            
            # Afficher les résultats
            result_text = f"✅ Embedding réussi!\n"
            result_text += f"📏 Dimensions: {len(embedding)}\n"
            result_text += f"📊 Premières valeurs: {embedding[:5]}...\n"
            result_text += f"🔢 Type: {type(embedding).__name__}\n"
            result_text += f"⚡ Somme: {sum(embedding):.4f}\n"
            result_text += f"📐 Norme: {(sum(x**2 for x in embedding) ** 0.5):.4f}"
            
            self.results_area.setText(result_text)
            self.results_area.setStyleSheet("""
                QTextEdit {
                    background-color: #e8f5e8;
                    border: 1px solid #4CAF50;
                    border-radius: 5px;
                    padding: 10px;
                    font-family: 'Courier New', monospace;
                }
            """)
        
        def _on_embedding_error(self, error_msg):
            """Affiche les erreurs"""
            self.search_controller.view.set_enabled(True)
            self.status_label.setText(f"❌ Erreur: {error_msg}")
            
            error_text = f"❌ Erreur d'embedding!\n\n"
            error_text += f"🔍 Message: {error_msg}\n"
            error_text += f"🔧 Vérifiez:\n"
            error_text += f"   • Connexion à Ollama ({ollama_url})\n"
            error_text += f"   • Modèle 'nomic-embed-text:v1.5' disponible\n"
            error_text += f"   • Service Ollama en cours d'exécution"
            
            self.results_area.setText(error_text)
            self.results_area.setStyleSheet("""
                QTextEdit {
                    background-color: #ffe8e8;
                    border: 1px solid #f44336;
                    border-radius: 5px;
                    padding: 10px;
                    font-family: 'Courier New', monospace;
                }
            """)
        
        def closeEvent(self, event):
            """Ferme proprement les threads avant de quitter"""
            if self.search_controller.embedding_manager.is_running():
                self.search_controller.embedding_manager.stop_embedding()
            event.accept()

    # Lancer l'application
    app = QApplication(sys.argv)
    window = TestWindow()
    window.show()
    
    print("🚀 Test de la barre de recherche avec Ollama")
    print(f"📍 URL Ollama: {ollama_url}")
    print("💡 Tapez un texte et appuyez sur Entrée pour tester l'embedding")
    
    sys.exit(app.exec())
