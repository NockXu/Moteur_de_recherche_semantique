import sys
import os
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QDockWidget
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import des widgets
from SearchBar.SearchBarController import SearchBarController
from ImportTool.ImportToolController import create_import_tool
from ImageSearchedContainer.ImageSearchedContainerController import ImageSearchedContainerController
from ImagePreview import create_image_preview

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Moteur de Recherche Sémantique")
        self.setMinimumSize(1200, 800)
        
        # Créer les contrôleurs
        self._setup_controllers()
        
        # Configurer l'interface
        self._setup_ui()
        
        # Connecter les signaux
        self._connect_signals()
    
    def _setup_controllers(self):
        """Initialise tous les contrôleurs"""
        # Barre de recherche
        self.search_controller = SearchBarController()
        
        # Import Tool (dans un dock)
        self.import_tool_controller = create_import_tool()
        
        # Conteneur d'images recherchées
        self.image_container_controller = ImageSearchedContainerController()
        
        # Preview d'image (dans un dock)
        self.image_preview_controller = create_image_preview()
    
    def _setup_ui(self):
        """Configure l'interface utilisateur"""
        # Widget central obligatoire avec QMainWindow
        central = QWidget()
        self.setCentralWidget(central)
        
        # Layout principal pour le widget central
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)
        
        # Section supérieure : Barre de recherche
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(0, 0, 0, 0)
        
        # Titre de l'application
        title_label = QLabel(" Moteur de Recherche Sémantique")
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #2c3e50; margin-bottom: 10px;")
        search_layout.addWidget(title_label)
        search_layout.addStretch()
        
        # Ajouter la barre de recherche
        search_layout.addWidget(self.search_controller.view)
        
        # Ajouter la section de recherche au layout principal
        search_widget = QWidget()
        search_widget.setLayout(search_layout)
        main_layout.addWidget(search_widget)
        
        # Zone centrale : Conteneur d'images
        main_layout.addWidget(self.image_container_controller.view, 1)  # Stretch factor 1
        
        # Créer les docks
        self._setup_docks()
    
    def _setup_docks(self):
        """Configure les docks latéraux"""
        
        # Dock gauche : Import Tool
        import_dock = QDockWidget("📁 Import d'images")
        import_dock.setWidget(self.import_tool_controller.get_view())
        import_dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, import_dock)
        
        # Dock droit : Preview d'image
        preview_dock = QDockWidget("🖼️ Aperçu")
        preview_dock.setWidget(self.image_preview_controller.get_view())
        preview_dock.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, preview_dock)
        
        # Masquer le dock de preview par défaut (s'ouvrira au clic sur une image)
        preview_dock.hide()
        
        # Stocker les références
        self.import_dock = import_dock
        self.preview_dock = preview_dock
    
    def _connect_signals(self):
        """Connecte les signaux entre les widgets"""
        # Quand une image est cliquée dans le conteneur
        self.image_container_controller.image_click_callback = self._on_image_clicked
        
        # Quand une recherche est effectuée
        self.search_controller.view.search_triggered.connect(self._on_search_triggered)
        
        # Connexion du widget de connexion Ollama
        connection_widget = self.import_tool_controller.get_connection_verificator()
        connection_widget.connection_status_changed.connect(self._on_connection_status_changed)
        
    def _on_image_clicked(self, image_path: str):
        """Gère le clic sur une image"""
        try:
            # Afficher l'image dans le preview
            self.image_preview_controller.set_image_by_path(image_path)
            
            # Afficher le dock de preview s'il est caché
            if self.preview_dock.isHidden():
                self.preview_dock.show()
            
            print(f"🖼️ Image sélectionnée: {os.path.basename(image_path)}")
            
        except Exception as e:
            print(f"❌ Erreur lors de l'affichage de l'image: {e}")
    
    def _on_search_triggered(self, search_text: str, embedding: list):
        """Gère le déclenchement d'une recherche"""
        try:
            print(f"🔍 Recherche: '{search_text}'")
            print(f"📊 Embedding dimension: {len(embedding) if embedding else 0}")
            
            # TODO: Implémenter la recherche réelle ici
            # Pour l'instant, afficher un message
            self.image_container_controller.clear_images()
            
        except Exception as e:
            print(f"❌ Erreur lors de la recherche: {e}")
    
    def _on_connection_status_changed(self, state, version: str, error_message: str):
        """Gère les changements de statut de connexion Ollama"""
        state_names = {
            0: "Déconnecté",  # DISCONNECTED
            1: "Connecté",     # CONNECTED  
            2: "Erreur"        # ERROR
        }
        
        state_name = state_names.get(state.value, "Inconnu")
        
        if state.value == 1:  # CONNECTED
            print(f"✅ Ollama connecté - Version: {version}")
        elif state.value == 2:  # ERROR
            print(f"❌ Erreur Ollama: {error_message}")
        else:
            print(f"⚫ Ollama: {state_name}")
    
    def cleanup(self):
        """Nettoie les ressources avant la fermeture"""
        try:
            print("🧹 Nettoyage de MainWindow...")
            
            # Nettoyer tous les contrôleurs
            if hasattr(self, 'import_tool_controller'):
                self.import_tool_controller.cleanup()
            
            # Les autres contrôleurs n'ont pas de méthode cleanup pour l'instant
            
            print("✅ Nettoyage de MainWindow terminé")
            
        except Exception as e:
            print(f"❌ Erreur lors du nettoyage de MainWindow: {e}")
    
    def closeEvent(self, event):
        """Gère la fermeture de la fenêtre"""
        try:
            self.cleanup()
            event.accept()
        except Exception as e:
            print(f"❌ Erreur lors de la fermeture: {e}")
            event.accept()  # Forcer la fermeture même en cas d'erreur


if __name__ == "__main__":
    import signal
    
    app = QApplication(sys.argv)
    
    # Gérer Ctrl+C proprement
    def signal_handler(signum, frame):
        print("\n🛑 Interruption détectée, fermeture propre...")
        if 'window' in locals():
            window.close()
        app.quit()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    # Créer et afficher la fenêtre principale
    window = MainWindow()
    window.show()
    
    print("🚀 Application démarrée")
    print("💡 Utilisez Ctrl+C pour fermer proprement")
    
    try:
        sys.exit(app.exec())
    except KeyboardInterrupt:
        print("\n👋 Au revoir !")